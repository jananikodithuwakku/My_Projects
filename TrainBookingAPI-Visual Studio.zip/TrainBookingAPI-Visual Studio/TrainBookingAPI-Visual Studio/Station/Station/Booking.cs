﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using static Station.Form1;

namespace Station
{
    public partial class Booking : Form
    {
        private int trainId;
        int bookingId;
        public Booking(int trainId)
        {
            InitializeComponent();
            this.trainId = trainId;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Yes.Checked || No.Checked)
            {
                string url = "https://localhost:44371/api/Booking" + trainId;
                HttpClient client = new HttpClient();
                BookingB booking = new BookingB();
                TrainB train = new TrainB();
                train.TrainId = trainId;
                booking.BookingId = bookingId;
                booking.PassengerName = textBox3.Text;
                booking.NICNumber = textBox4.Text;
                booking.BookingTime = textBox5.Text;


                booking.IsConfirmed = Yes.Checked;

                string data = (new JavaScriptSerializer()).Serialize(booking);
                var content = new StringContent(data, UnicodeEncoding.UTF8, "application/json");
                var res = client.PutAsync(url, content).Result;
                if (res.IsSuccessStatusCode)
                {
                    MessageBox.Show("Booking details were added successfully.");


                    Summary summaryForm = new Summary();
                    summaryForm.TrainId = trainId;
                    summaryForm.BookingId = bookingId;
                    summaryForm.PassengerName = textBox3.Text;
                    summaryForm.NICNumber = textBox4.Text;
                    summaryForm.BookingTime = textBox5.Text;
                    summaryForm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Failed to add train details.");
                }
            }
            else
            {
                MessageBox.Show("Please select booking confirmation status (Yes or No).", "Confirmation Status", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        public class BookingB
        {
            public int BookingId { get; set; }
            public string PassengerName { get; set; }
            public string NICNumber { get; set; }
            public string BookingTime { get; set; }
            public bool IsConfirmed { get; set; }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
