using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebTrainBooking.Pages
{
    public class SummaryModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public int BookingId { get; set; }
        [BindProperty(SupportsGet = true)]
        public string PassengerName { get; set; }
        [BindProperty(SupportsGet = true)]
        public string NICNumber { get; set; }
        [BindProperty(SupportsGet = true)]
        public string BookingTime { get; set; }

       
        public void OnGet()
        {
           
           
        }
    }
}
