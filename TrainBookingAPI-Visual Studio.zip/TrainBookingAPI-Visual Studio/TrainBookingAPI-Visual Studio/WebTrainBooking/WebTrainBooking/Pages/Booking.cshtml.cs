using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text.Json;
using System.Text;
using WebTrainBooking.Model;

namespace WebTrainBooking.Pages
{
    public class BookingModel : PageModel
    {
        [BindProperty]
        public Train train { get; set; }
        public Booking booking { get; set; }
        public async Task<IActionResult> OnPost()
        {
            string url = "https://localhost:44371/api/Booking";
            var jcontent = new StringContent(JsonSerializer.Serialize(train),
                Encoding.UTF8, "application/json");
            using HttpClient client = new HttpClient();
            using HttpResponseMessage res = await client.PostAsync(url, jcontent);
            if (res.IsSuccessStatusCode)
            {
                TempData["success"] = "Booking successfully";
                // Redirect to the Summary page with booking details
                return RedirectToPage("Summary", new
                {
                    BookingId = booking.BookingId,
                    PassengerName = booking.PassengerName,
                    NICNumber = booking.NICNumber,
                    BookingTime = booking.BookingTime
                });
            }
            else
            {
                TempData["failure"] = "Booking Failed";
                return RedirectToPage("Train");
            }
        }
    }
}
