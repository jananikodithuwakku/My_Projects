﻿using System.ComponentModel.DataAnnotations;

namespace WebTrainBooking.Model
{
    public class Train
    {
        public int TrainId { get; set; }
        public string StartStation { get; set; } 
        public string EndStation { get; set; } 
        public string DepartureTime { get; set; } 
        public string ArrivalTime { get; set; }
        
    }
}
