﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;

namespace Agent
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string searchTerm = textBox1.Text.Trim().ToLower();
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                foreach (DataGridViewRow row in DGV1.Rows)
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm))
                        {
                            row.Selected = true;

                            DGV1.FirstDisplayedScrollingRowIndex = row.Index;
                            return;
                        }
                    }
                }
                MessageBox.Show("No matching records found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadPassenger();
        }

        public void LoadPassenger()
        {
            string url = "https://localhost:44371/api/Train";
            WebClient client = new WebClient();
            client.Headers["content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.DownloadString(url);
            DGV1.DataSource = null;
            DGV1.DataSource = (new JavaScriptSerializer()).
                Deserialize<List<TrainB>>(json);
        }

        public class TrainB
        {
            public int TrainId { get; set; }
            public string StartStation { get; set; }
            public string EndStation { get; set; }
            public string DepartureTime { get; set; }
            public string ArrivalTime { get; set; }
        }

        private void SBbtn_Click(object sender, EventArgs e)
        {
            if (DGV1.SelectedRows.Count > 0)
            {

                int trainId = (int)DGV1.SelectedRows[0].Cells["TrainId"].Value;


                Booking bookingForm = new Booking(trainId);
                bookingForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a train to book.", "Select Train", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
    }

