﻿using System.ComponentModel.DataAnnotations;

namespace TrainBooking.Model
{
    public class Passenger
    {
        [Key]
        public int PassengerId { get; set; }

        [Required]
        public string Name { get; set; } = "Not Given";

        [Required]
        public string PhoneNumber { get; set; } = "Not Given";
    }
}
