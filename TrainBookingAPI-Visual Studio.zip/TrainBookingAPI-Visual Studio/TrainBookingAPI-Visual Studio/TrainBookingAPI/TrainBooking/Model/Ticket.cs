﻿using System.ComponentModel.DataAnnotations;

namespace TrainBooking.Model
{
    public class Ticket
    {
        [Key]
        public int TicketId { get; set; }

        [Required]
        public int BookingId { get; set; }

        [Required]
        public int SeatNumber { get; set; }

        [Required]
        public decimal Price { get; set; }

        [Required]
        public string BookingTime { get; set; } = "Not Given";

        [Required]
        public string DepartureTime { get; set; } = "Not Given";

        [Required]
        public string ArrivalTime { get; set; } = "Not Given";
    }
}
