﻿using Microsoft.EntityFrameworkCore;
using TrainBooking.Model;
namespace TrainBooking.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options)
            : base(options)
        {

        }

        public DbSet<Train> trains { get; set; }
        public DbSet<Seats> seats  { get; set; }
        public DbSet<Booking> booking { get; set; }
        public DbSet<Ticket> tickts { get; set; }
        public DbSet<Passenger> Passengers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Ticket>().
                Property(t => t.Price).HasColumnType("decimal(18,2)");
            modelBuilder.Entity<Train>();
            modelBuilder.Entity<Booking>();
            modelBuilder.Entity<Seats>();
            modelBuilder.Entity<Passenger>();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           string conn = "Data Source=.;User ID=sa;Password=sql;Initial Catalog=Train_db;Connect Timeout=30;Encrypt=False;" +
                "Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False";
            optionsBuilder.UseSqlServer(conn);
        }
    }
}
