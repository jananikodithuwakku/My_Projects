﻿using System.Collections.Generic;
using System.Linq;
using TrainBooking.Model;

namespace TrainBooking.Data
{
    public class BookingRepository
    {
        private readonly AppDBContext dbContext; 

        public BookingRepository(AppDBContext context)
        {
            dbContext = context;
        }

        public bool CreateBooking(Booking booking)
        {
            if (booking != null)
            {
                
                var existingBookingsCount = dbContext.booking.Count(b => b.NICNumber == booking.NICNumber);
                if (existingBookingsCount >= 5)
                {
                    return false; 
                }

                dbContext.booking.Add(booking);
                return Save();
            }
            else
            {
                return false;
            }
        }

        public bool Save()
        {
            int count = dbContext.SaveChanges();
            return count > 0;
        }

        public bool UpdateBooking(Booking booking)
        {
            dbContext.booking.Update(booking);
            return Save();
        }

        public bool RemoveBooking(Booking booking)
        {
            dbContext.booking.Remove(booking);
            return Save();
        }

        public Booking GetBooking(int id)
        {
            return dbContext.booking.FirstOrDefault(booking => booking.BookingId == id);
        }

        public IEnumerable<Booking> GetBookings()
        {
            return dbContext.booking.ToList();
        }

      
        public bool AddTicketToBooking(int bookingId, Ticket ticket)
        {
            var booking = GetBooking(bookingId);
            if (booking != null)
            {
                booking.Tickets.Add(ticket);
                return UpdateBooking(booking);
            }
            else
            {
                return false;
            }
        }
    }
}
