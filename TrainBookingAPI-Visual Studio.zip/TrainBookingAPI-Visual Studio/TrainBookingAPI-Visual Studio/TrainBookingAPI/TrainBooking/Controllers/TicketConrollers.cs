﻿using Microsoft.AspNetCore.Mvc;
using TrainBooking.Model;
using TrainBooking.Data;
using TrainBooking.DTO;
using AutoMapper;
using System;
using System.Collections.Generic;

namespace TrainBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TicketController : Controller
    {
        private readonly IMapper _mapper;
        private readonly TicketRepository _repository;

        public TicketController(TicketRepository ticketRepository, IMapper mapper)
        {
            _repository = ticketRepository;
            _mapper = mapper;
        }

        [HttpPost]
        public ActionResult CreateTicket(TicketCreateDTO createDTO)
        {
            var ticket = _mapper.Map<Ticket>(createDTO);
            if (_repository.CreateTicket(ticket))
                return CreatedAtRoute("GetTicketById", new { id = ticket.TicketId }, ticket);
            else
                return BadRequest();
        }

        [HttpGet("{id}", Name = "GetTicketById")]
        public ActionResult<TicketRadeDTO> GetTicket(int id)
        {
            var ticket = _repository.GetTicket(id);
            if (ticket != null)
                return Ok(_mapper.Map<TicketRadeDTO>(ticket));
            else
                return NotFound();
        }

        [HttpGet]
        public ActionResult<IEnumerable<TicketRadeDTO>> GetTickets()
        {
            var tickets = _repository.GetTickets();
            return Ok(_mapper.Map<IEnumerable<TicketRadeDTO>>(tickets));
        }

        [HttpPut("{id}")]
        public ActionResult UpdateTicket(int id, TicketCreateDTO createDTO)
        {
            var ticket = _mapper.Map<Ticket>(createDTO); // Create a ticket
            ticket.TicketId = id; // Set the ticket ID
            if (_repository.UpdateTicket(ticket))
                return Ok();
            else
                return NotFound();
        }
    }
}
