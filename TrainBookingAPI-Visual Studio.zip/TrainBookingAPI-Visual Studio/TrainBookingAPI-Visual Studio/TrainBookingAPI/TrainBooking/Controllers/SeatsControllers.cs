﻿using Microsoft.AspNetCore.Mvc;
using TrainBooking.Model;
using TrainBooking.Data;
using TrainBooking.DTO;
using AutoMapper;
using System;
using System.Collections.Generic;

namespace TrainBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SeatsController : Controller
    {
        private readonly IMapper _mapper;
        private readonly SeatsRepository _repository;

        public SeatsController(SeatsRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        [HttpPost]
        public ActionResult CreateSeat(SeatsCreateDTO createDTO)
        {
            var seat = _mapper.Map<Seats>(createDTO);
            if (_repository.CreateSeat(seat))
                return Ok();
            else
                return BadRequest();
        }

        [HttpGet("{seatNumber}")]
        public ActionResult<SeatsReadDTO> GetSeat(int seatNumber)
        {
            var seat = _repository.GetSeat(seatNumber);
            if (seat == null)
                return NotFound();

            var seatDTO = _mapper.Map<SeatsReadDTO>(seat);
            return Ok(seatDTO);
        }

        [HttpPut("{seatNumber}")]
        public ActionResult UpdateSeat(int seatNumber, SeatsCreateDTO updateDTO)
        {
            var seat = _repository.GetSeat(seatNumber);
            if (seat == null)
                return NotFound();

            _mapper.Map(updateDTO, seat);
            _repository.UpdateSeat(seat);
            return NoContent();
        }

        [HttpDelete("{seatNumber}")]
        public ActionResult DeleteSeat(int seatNumber)
        {
            var seat = _repository.GetSeat(seatNumber);
            if (seat == null)
                return NotFound();

            _repository.RemoveSeat(seat);
            return Ok();
        }
    }
}
