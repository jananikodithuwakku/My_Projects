﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using TrainBooking.Model;
using TrainBooking.Data;
using TrainBooking.DTO;
using AutoMapper;
using System.Linq;

namespace TrainBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly BookingRepository _repository;

        public BookingController(BookingRepository bookingRepository, IMapper mapper)
        {
            _repository = bookingRepository;
            _mapper = mapper;
        }

        [HttpPost]
        public ActionResult CreateBooking(BookingCreateDTO bookingCreate)
        {
            var booking = _mapper.Map<Booking>(bookingCreate);

            
            var existingBookingsCount = _repository.GetBookings().Count(b => b.NICNumber == booking.NICNumber);
            if (existingBookingsCount >= 5)
            {
                return BadRequest("Maximum number of bookings reached for this NIC number.");
            }

            if (_repository.CreateBooking(booking))
                return Ok();
            else
                return BadRequest();
        }

        [HttpGet("{id}", Name = "GetBookingById")]
        public ActionResult<BookingReadDTO> GetBooking(int id)
        {
            var booking = _repository.GetBooking(id);
            if (booking != null)
                return Ok(_mapper.Map<BookingReadDTO>(booking));
            else
                return NotFound();
        }

        [HttpGet]
        public ActionResult<IEnumerable<BookingReadDTO>> GetBookings()
        {
            var bookings = _repository.GetBookings();
            return Ok(_mapper.Map<IEnumerable<BookingReadDTO>>(bookings));
        }

        [HttpDelete("{id}")]
        public ActionResult DeleteBooking(int id)
        {
            var booking = _repository.GetBooking(id);
            if (booking != null)
            {
                _repository.RemoveBooking(booking);
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut("{id}")]
        public ActionResult UpdateBooking(int id, BookingCreateDTO createDTO)
        {
            var booking = _mapper.Map<Booking>(createDTO); 
            booking.BookingId = id;
            if (_repository.UpdateBooking(booking))
                return Ok();
            else
                return NotFound();
        }

       
        [HttpPost("{bookingId}/AddTicket")]
        public ActionResult AddTicketToBooking(int bookingId, TicketCreateDTO ticketCreate)
        {
            var ticket = _mapper.Map<Ticket>(ticketCreate);
            if (_repository.AddTicketToBooking(bookingId, ticket))
                return Ok();
            else
                return NotFound();
        }
    }
}
