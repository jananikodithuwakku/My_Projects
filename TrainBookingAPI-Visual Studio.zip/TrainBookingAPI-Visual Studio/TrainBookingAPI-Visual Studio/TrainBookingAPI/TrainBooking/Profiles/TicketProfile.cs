﻿using AutoMapper;
using TrainBooking.DTO;
using TrainBooking.Model;

namespace TrainBooking.Profiles
{
    public class TicketProfile: Profile
    {
        public TicketProfile()
        {
            CreateMap<Ticket, TicketRadeDTO>();
            CreateMap<TicketCreateDTO, Ticket>();
        }
    }
}
