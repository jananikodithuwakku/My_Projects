﻿using AutoMapper;
using TrainBooking.DTO;
using TrainBooking.Model;

namespace TrainBooking.Profiles
{
    public class SeatsProfile:Profile
    {
        public SeatsProfile()
        {
            CreateMap<Seats, SeatsReadDTO>();
            CreateMap<SeatsCreateDTO, Seats>();
        }
    }
}
