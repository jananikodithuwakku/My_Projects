﻿using AutoMapper;
using TrainBooking.Model;
using TrainBooking.DTO;

namespace TrainBooking.Profiles
{
    public class PassengerProfile: Profile
    {
        public PassengerProfile()
        {
            CreateMap <Passenger, PassengerReadDTO>();
            CreateMap<PassengerCreateDTO, Passenger>();
        }
    }
}
