﻿namespace TrainBooking.DTO
{
    public class BookingReadDTO
    {
        public int BookingId { get; set; }
        public string PassengerName { get; set; }
        public string NICNumber { get; set; }
        public string BookingTime { get; set; }
        public bool IsConfirmed { get; set; }
    }
}
