﻿namespace TrainBooking.DTO
{
    public class SeatsReadDTO
    {
        public int SeatNumber { get; set; }
        public bool IsAvailable { get; set; }
    }
}
