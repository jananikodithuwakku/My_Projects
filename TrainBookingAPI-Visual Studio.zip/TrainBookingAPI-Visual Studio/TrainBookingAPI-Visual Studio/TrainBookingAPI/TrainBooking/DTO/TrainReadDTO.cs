﻿using System.ComponentModel.DataAnnotations;
using TrainBooking.Model;

namespace TrainBooking.DTO
{
    public class TrainReadDTO
    {
        public int TrainId { get; set; }
        public string StartStation { get; set; }
        public string EndStation { get; set; }
        public string DepartureTime { get; set; }
        public string ArrivalTime { get; set; }
        public List<Seats> Seats { get; set; }
        
    }
}
