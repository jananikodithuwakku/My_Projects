﻿namespace TrainBooking.DTO
{
    public class BookingCreateDTO
    {
        public string PassengerName { get; set; }
        public string NICNumber { get; set; }
        public string BookingTime { get; set; }
        public bool IsConfirmed { get; set; }
    }
}
