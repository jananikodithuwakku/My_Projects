﻿using System.ComponentModel.DataAnnotations;

namespace TrainBooking.DTO
{
    public class PassengerCreateDTO
    {
        public int PassengerId { get; set; }

        public string Name { get; set; } 

        
    }
}
