﻿namespace TrainBooking.DTO
{
    public class SeatsCreateDTO
    {
        public int SeatNumber { get; set; }
        public bool IsAvailable { get; set; }
    }
}
