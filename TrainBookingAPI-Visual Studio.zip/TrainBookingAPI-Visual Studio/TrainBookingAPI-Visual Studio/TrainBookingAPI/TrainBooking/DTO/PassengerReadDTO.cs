﻿using System.ComponentModel.DataAnnotations;

namespace TrainBooking.DTO
{
    public class PassengerReadDTO
    {
        public int PassengerId { get; set; }

        public string Name { get; set; }

        public string PhoneNumber { get; set; }
    }
}
    

