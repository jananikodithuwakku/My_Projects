<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/dashboard.css">
    <title>Dashboard</title>
</head>
<body background="Images/2.jpg">
    
        <div class="logo">
            <img src="Images/Logo.jpg" alt="THE OUTER CLOVE RESTAURANT LOGO">
        </div>
        <h1>THE OUTER CLOVE RESTAURANT</h1>
        <h1>Admin Dashboard</h1>

        <section class="dashboard">
             <div><p><a href="A_Reservation.php">Customer Reservation</a></p></div>
             <div><p><a href="A_contact.php">Customer Contact</a></p></div>           
             <div><p><a href="A_order.php">Customer Order</a></p></div>
             <div><p><a href="A_offers.php">Customer Offer Order</a></p></div>
             <div><p><a href="Home.php">Website</a></p></div>

            
            
        </section>

</body>
</html>   